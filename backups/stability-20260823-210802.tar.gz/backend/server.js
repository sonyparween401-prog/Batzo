require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { registerRoutes } = require('./routes');

const { registerUser } = require('./auth');
const { requestOtp, verifyOtp } = require('./otp');
const { loginWithFirebaseIdToken } = require('./firebase-user');

const cricketRoutes = require("./cricket-routes");
const app = express();

// BATZO CRICKET API ROUTES


// BATZO CRICKET API - MUST BE BEFORE SPA/404 HANDLERS

const PORT = process.env.PORT || 3000;

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '100kb' }));
// BATZO REAL CRICKET ROUTES
app.use("/api/cricket", cricketRoutes);

// BATZO REAL CRICKET API

// BATZO REAL CRICKET API ROUTES


const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false
});

app.use('/api/', apiLimiter);

app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    service: 'Batzo API',
    status: 'healthy'
  });
});

app.post('/api/register', async (req, res) => {
  try {
    const { registerRoutes } = require('./routes');

const { name, mobile, password } = req.body;
    const user = await registerUser(name, mobile, password);

    res.status(201).json({
      success: true,
      message: 'Registration successful',
      user
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});


app.post('/api/request-otp', async (req, res) => {
  try {
    const { mobile } = req.body || {};
    const result = requestOtp(mobile);

    /*
      SMS PROVIDER HOOK:
      Set up your SMS provider here.
      Never expose provider API keys in frontend code.

      For now the OTP is generated securely and stored server-side.
      Real SMS delivery will be enabled after provider credentials
      are configured.
    */

    const providerConfigured =
      !!process.env.SMS_PROVIDER &&
      !!process.env.SMS_API_KEY;

    if (!providerConfigured) {
      return res.status(503).json({
        success: false,
        code: 'SMS_PROVIDER_NOT_CONFIGURED',
        message: 'SMS provider is not configured yet.'
      });
    }

    return res.json({
      success: true,
      message: 'OTP request accepted.',
      expiresInSeconds: result.expiresInSeconds
    });
  } catch (err) {
    const status = err.code === 'RATE_LIMIT' ? 429 : 400;
    return res.status(status).json({
      success: false,
      message: err.message
    });
  }
});

app.post('/api/verify-otp', async (req, res) => {
  try {
    const { mobile, otp } = req.body || {};
    const result = verifyOtp(mobile, otp);

    return res.json({
      success: true,
      verified: true,
      mobile: result.phone,
      message: 'OTP verified successfully.'
    });
  } catch (err) {
    return res.status(400).json({
      success: false,
      verified: false,
      message: err.message
    });
  }
});


app.post('/api/auth/firebase', async (req, res) => {
  try {
    const { idToken } = req.body || {};

    if (!idToken || typeof idToken !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'Firebase ID token is required.'
      });
    }

    const result = await loginWithFirebaseIdToken(idToken);

    return res.json({
      success: true,
      ...result
    });
  } catch (err) {
    console.error('Firebase authentication failed:', err.message);

    return res.status(401).json({
      success: false,
      message: 'Firebase authentication failed.'
    });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Batzo API running on http://0.0.0.0:${PORT}`);
});


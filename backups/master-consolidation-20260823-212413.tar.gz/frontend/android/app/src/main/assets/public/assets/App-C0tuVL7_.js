import{n as e,r as t,t as n}from"./index-AL4CRR5E.js";var r=[{name:`Rohit Sharma`,role:`Batter`,team:`IND`,credit:`9.5`,photo:`/players/rohit-sharma.jpg`},{name:`Virat Kohli`,role:`Batter`,team:`IND`,credit:`9.5`,photo:`/players/virat-kohli.jpg`},{name:`Jasprit Bumrah`,role:`Bowler`,team:`IND`,credit:`9.0`,photo:`/players/jasprit-bumrah.jpg`},{name:`Hardik Pandya`,role:`All-rounder`,team:`IND`,credit:`9.0`,photo:`/players/hardik-pandya.jpg`},{name:`KL Rahul`,role:`Wicket-keeper`,team:`IND`,credit:`8.5`,photo:`/players/rohit-sharma.jpg`},{name:`Travis Head`,role:`Batter`,team:`AUS`,credit:`9.0`,photo:`/players/travis-head.jpg`},{name:`Pat Cummins`,role:`Bowler`,team:`AUS`,credit:`9.0`,photo:`/players/pat-cummins.jpg`}],i=[{name:`Mega Contest`,prize:`₹50 Lakhs`,entry:`₹49`,spots:`2.1L`,joined:`1.84L`},{name:`Head To Head`,prize:`₹1,800`,entry:`₹49`,spots:`2`,joined:`1`},{name:`Small Contest`,prize:`₹25,000`,entry:`₹99`,spots:`1,000`,joined:`642`}];function a(e=`IND vs AUS`){window.dispatchEvent(new CustomEvent(`batzo:team`,{detail:{match:e}}))}function o(e=i[0]){window.dispatchEvent(new CustomEvent(`batzo:contest`,{detail:{contest:e}}))}var s=t(e(),1),c=n(),l=[{id:1,league:`T20`,a:`India`,ac:`IND`,af:`🇮🇳`,as:`168/4`,b:`Australia`,bc:`AUS`,bf:`🇦🇺`,bs:`142/7`,over:`17.2 ov`,viewers:`2.1L people watching`}],u=[{id:2,league:`T20`,a:`India`,ac:`IND`,af:`🇮🇳`,b:`Australia`,bc:`AUS`,bf:`🇦🇺`,time:`Today`,clock:`7:30 PM`},{id:3,league:`T20`,a:`Pakistan`,ac:`PAK`,af:`🇵🇰`,b:`New Zealand`,bc:`NZ`,bf:`🇳🇿`,time:`Tomorrow`,clock:`3:30 PM`},{id:4,league:`T20`,a:`England`,ac:`ENG`,af:`🏴`,b:`South Africa`,bc:`SA`,bf:`🇿🇦`,time:`Tomorrow`,clock:`7:30 PM`}],d=[{title:`Mega Contest`,prize:`₹50 Lakhs`,entry:`₹49`,spots:`2.1L`},{title:`Head To Head`,prize:`₹1,800`,entry:`₹49`,spots:`2`},{title:`Small Contest`,prize:`₹25,000`,entry:`₹99`,spots:`1,000`}];function f(){return(0,c.jsxs)(`div`,{className:`logo-area`,children:[(0,c.jsxs)(`div`,{className:`batzo-logo`,children:[(0,c.jsx)(`span`,{children:`B`}),(0,c.jsx)(`span`,{children:`A`}),(0,c.jsx)(`span`,{children:`T`}),(0,c.jsx)(`span`,{children:`Z`}),(0,c.jsx)(`span`,{children:`O`})]}),(0,c.jsxs)(`div`,{className:`logo-line`,children:[(0,c.jsx)(`i`,{}),(0,c.jsx)(`strong`,{children:`CRICKET HUB`}),(0,c.jsx)(`i`,{})]})]})}function p({setNotice:e}){return(0,c.jsxs)(`header`,{className:`top-header`,children:[(0,c.jsx)(f,{}),(0,c.jsxs)(`div`,{className:`header-right`,children:[(0,c.jsxs)(`button`,{className:`notification-btn`,onClick:()=>e(`No new notifications`),"aria-label":`Notifications`,children:[(0,c.jsx)(`span`,{className:`bell`,children:`♧`}),(0,c.jsx)(`b`,{children:`3`})]}),(0,c.jsxs)(`button`,{className:`wallet-box`,onClick:()=>e(`Wallet balance: ₹0`),children:[(0,c.jsx)(`span`,{className:`wallet-icon`,children:`▰`}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`small`,{children:`Wallet Balance`}),(0,c.jsx)(`strong`,{children:`₹0`})]}),(0,c.jsx)(`em`,{children:`›`})]})]})]})}function m({icon:e,title:t,sub:n,type:r,onClick:i}){return(0,c.jsxs)(`button`,{className:`quick-card ${r||``}`,onClick:i,children:[(0,c.jsx)(`div`,{className:`quick-icon`,children:e}),(0,c.jsx)(`div`,{className:`quick-title`,children:t}),(0,c.jsx)(`div`,{className:`quick-sub`,children:n}),(0,c.jsx)(`span`,{className:`quick-arrow`,children:`›`})]})}function h({match:e,onOpen:t}){return(0,c.jsxs)(`button`,{className:`live-match-card`,onClick:()=>t(e),children:[(0,c.jsxs)(`div`,{className:`live-card-top`,children:[(0,c.jsxs)(`span`,{children:[(0,c.jsx)(`i`,{className:`red-dot`}),` LIVE • `,e.league]}),(0,c.jsx)(`b`,{children:`◉ LIVE`})]}),(0,c.jsxs)(`div`,{className:`live-score-row`,children:[(0,c.jsxs)(`div`,{className:`side-team`,children:[(0,c.jsx)(`div`,{className:`flag`,children:e.af}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`strong`,{children:e.ac}),(0,c.jsx)(`small`,{children:e.a})]})]}),(0,c.jsxs)(`div`,{className:`score`,children:[(0,c.jsx)(`strong`,{children:e.as}),(0,c.jsx)(`small`,{children:e.over})]}),(0,c.jsx)(`div`,{className:`versus`,children:`VS`}),(0,c.jsxs)(`div`,{className:`score right-score`,children:[(0,c.jsx)(`strong`,{children:e.bs}),(0,c.jsx)(`small`,{})]}),(0,c.jsxs)(`div`,{className:`side-team right-team`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`strong`,{children:e.bc}),(0,c.jsx)(`small`,{children:e.b})]}),(0,c.jsx)(`div`,{className:`flag`,children:e.bf})]})]}),(0,c.jsxs)(`div`,{className:`live-bottom`,children:[(0,c.jsxs)(`div`,{className:`watching`,children:[(0,c.jsx)(`span`,{children:`●`}),(0,c.jsx)(`b`,{children:e.viewers})]}),(0,c.jsxs)(`span`,{className:`view-button`,children:[`VIEW MATCH `,(0,c.jsx)(`b`,{children:`→`})]})]})]})}function g({match:e,onOpen:t}){return(0,c.jsxs)(`button`,{className:`upcoming-card`,onClick:()=>t(e),children:[(0,c.jsxs)(`div`,{className:`up-team`,children:[(0,c.jsx)(`span`,{className:`mini-flag`,children:e.af}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`strong`,{children:e.ac}),(0,c.jsx)(`small`,{children:e.a})]})]}),(0,c.jsxs)(`div`,{className:`match-time-box`,children:[(0,c.jsx)(`span`,{children:e.time}),(0,c.jsx)(`strong`,{children:e.clock})]}),(0,c.jsxs)(`div`,{className:`up-team away`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`strong`,{children:e.bc}),(0,c.jsx)(`small`,{children:e.b})]}),(0,c.jsx)(`span`,{className:`mini-flag`,children:e.bf})]}),(0,c.jsxs)(`span`,{className:`contest-action`,children:[`VIEW CONTESTS `,(0,c.jsx)(`b`,{children:`→`})]})]})}function _({contest:e,onClick:t}){return(0,c.jsxs)(`button`,{className:`contest-card`,onClick:t,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`small`,{children:`WINNING PRIZE`}),(0,c.jsx)(`strong`,{children:e.prize})]}),(0,c.jsxs)(`div`,{className:`contest-info`,children:[(0,c.jsx)(`b`,{children:e.title}),(0,c.jsxs)(`span`,{children:[e.spots,` spots`]})]}),(0,c.jsxs)(`div`,{className:`join-box`,children:[(0,c.jsx)(`small`,{children:`JOIN`}),(0,c.jsx)(`b`,{children:e.entry})]})]})}function v(){let[e,t]=(0,s.useState)(`home`),[n,r]=(0,s.useState)(``),[i,a]=(0,s.useState)(``),o=e=>{r(`${e.a} vs ${e.b} — Match Centre`),t(`matches`)},f=(0,s.useMemo)(()=>{let e=i.trim().toLowerCase();return e?u.filter(t=>`${t.a} ${t.b} ${t.ac} ${t.bc} ${t.league}`.toLowerCase().includes(e)):u},[i]),v=e=>{r(`${e} section is ready for the next Batzo release.`)};return(0,c.jsxs)(`div`,{className:`batzo-app`,children:[(0,c.jsx)(p,{setNotice:r}),(0,c.jsxs)(`main`,{className:`main-content`,children:[n&&(0,c.jsxs)(`button`,{className:`notice-bar`,onClick:()=>r(``),children:[(0,c.jsx)(`span`,{children:n}),(0,c.jsx)(`b`,{children:`×`})]}),e===`home`&&(0,c.jsxs)(c.Fragment,{children:[(0,c.jsxs)(`section`,{className:`hero-banner`,children:[(0,c.jsxs)(`div`,{className:`hero-copy`,children:[(0,c.jsx)(`span`,{className:`hero-kicker`,children:`THE NEW CRICKET EXPERIENCE`}),(0,c.jsxs)(`h1`,{children:[`Play smart.`,(0,c.jsx)(`br`,{}),(0,c.jsx)(`span`,{children:`Play Batzo.`})]}),(0,c.jsxs)(`p`,{children:[`Create your best XI, join contests`,(0,c.jsx)(`br`,{}),`and follow every ball.`]}),(0,c.jsxs)(`button`,{className:`hero-button`,onClick:()=>t(`matches`),children:[`EXPLORE MATCHES `,(0,c.jsx)(`b`,{children:`→`})]})]}),(0,c.jsxs)(`div`,{className:`hero-cricket`,children:[(0,c.jsx)(`div`,{className:`stadium-lights`,children:`✦ ✦`}),(0,c.jsx)(`div`,{className:`cricket-ring ring-one`}),(0,c.jsx)(`div`,{className:`cricket-ring ring-two`}),(0,c.jsx)(`div`,{className:`cricket-player`,children:`🏏`}),(0,c.jsx)(`div`,{className:`cricket-ball`,children:`🏏`})]}),(0,c.jsxs)(`div`,{className:`hero-dots`,children:[(0,c.jsx)(`i`,{className:`active`}),(0,c.jsx)(`i`,{}),(0,c.jsx)(`i`,{}),(0,c.jsx)(`i`,{})]})]}),(0,c.jsxs)(`section`,{className:`quick-grid`,children:[(0,c.jsx)(m,{icon:`🏏`,title:`Matches`,sub:`Live & upcoming`,type:`green-card`,onClick:()=>t(`matches`)}),(0,c.jsx)(m,{icon:`🏆`,title:`My Contests`,sub:`Track entries`,type:`gold-card`,onClick:()=>t(`contests`)}),(0,c.jsx)(m,{icon:`👥`,title:`My Teams`,sub:`Build your XI`,type:`blue-card`,onClick:()=>t(`teams`)}),(0,c.jsx)(m,{icon:`🎁`,title:`Rewards`,sub:`Coming soon`,type:`pink-card`,onClick:()=>v(`Rewards`)})]}),(0,c.jsxs)(`section`,{className:`section-block`,children:[(0,c.jsxs)(`div`,{className:`section-heading`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`span`,{children:`PLAY NOW`}),(0,c.jsx)(`h2`,{children:`Live Matches`})]}),(0,c.jsx)(`button`,{onClick:()=>t(`matches`),children:`View all →`})]}),l.map(e=>(0,c.jsx)(h,{match:e,onOpen:o},e.id))]}),(0,c.jsxs)(`section`,{className:`section-block`,children:[(0,c.jsxs)(`div`,{className:`section-heading`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`span`,{children:`DON'T MISS OUT`}),(0,c.jsx)(`h2`,{children:`Upcoming Matches`})]}),(0,c.jsx)(`button`,{onClick:()=>t(`matches`),children:`View all →`})]}),(0,c.jsx)(`div`,{className:`upcoming-list`,children:u.slice(0,2).map(e=>(0,c.jsx)(g,{match:e,onOpen:o},e.id))})]}),(0,c.jsxs)(`section`,{className:`section-block`,children:[(0,c.jsxs)(`div`,{className:`section-heading`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`span`,{children:`TOP PICKS`}),(0,c.jsx)(`h2`,{children:`Popular Contests`})]}),(0,c.jsx)(`button`,{onClick:()=>t(`contests`),children:`View all →`})]}),(0,c.jsx)(`div`,{className:`contest-list`,children:d.map(e=>(0,c.jsx)(_,{contest:e,onClick:()=>v(e.title)},e.title))})]})]}),e===`matches`&&(0,c.jsxs)(`section`,{className:`matches-page`,children:[(0,c.jsxs)(`div`,{className:`page-heading`,children:[(0,c.jsx)(`span`,{children:`BATZO CRICKET`}),(0,c.jsx)(`h1`,{children:`Matches`}),(0,c.jsx)(`p`,{children:`Choose a match and enter the action.`})]}),(0,c.jsxs)(`div`,{className:`search-field`,children:[(0,c.jsx)(`span`,{children:`⌕`}),(0,c.jsx)(`input`,{value:i,onChange:e=>a(e.target.value),placeholder:`Search teams or matches`})]}),(0,c.jsx)(`div`,{className:`match-section-title`,children:`LIVE`}),l.map(e=>(0,c.jsx)(h,{match:e,onOpen:o},e.id)),(0,c.jsx)(`div`,{className:`match-section-title upcoming-title`,children:`UPCOMING`}),(0,c.jsx)(`div`,{className:`upcoming-list`,children:f.map(e=>(0,c.jsx)(g,{match:e,onOpen:o},e.id))})]}),e===`contests`&&(0,c.jsxs)(`section`,{className:`simple-page`,children:[(0,c.jsxs)(`div`,{className:`page-heading`,children:[(0,c.jsx)(`span`,{children:`COMPETE`}),(0,c.jsx)(`h1`,{children:`Contests`}),(0,c.jsx)(`p`,{children:`Choose your contest and play your way.`})]}),(0,c.jsx)(`div`,{className:`contest-list`,children:d.map(e=>(0,c.jsx)(_,{contest:e,onClick:()=>v(e.title)},e.title))})]}),e===`teams`&&(0,c.jsxs)(`section`,{className:`empty-page`,children:[(0,c.jsx)(`div`,{className:`empty-icon`,children:`👥`}),(0,c.jsx)(`span`,{children:`YOUR SQUADS`}),(0,c.jsx)(`h1`,{children:`My Teams`}),(0,c.jsx)(`p`,{children:`Create and manage your fantasy cricket teams here.`}),(0,c.jsx)(`button`,{className:`hero-button`,onClick:()=>v(`Team Builder`),children:`CREATE TEAM →`})]}),e===`profile`&&(0,c.jsxs)(`section`,{className:`empty-page`,children:[(0,c.jsx)(`div`,{className:`profile-icon`,children:`B`}),(0,c.jsx)(`span`,{children:`BATZO ACCOUNT`}),(0,c.jsx)(`h1`,{children:`Your Profile`}),(0,c.jsx)(`p`,{children:`Profile, wallet and account settings.`}),(0,c.jsx)(`button`,{className:`outline-button`,onClick:()=>v(`Account Settings`),children:`ACCOUNT SETTINGS`})]})]}),(0,c.jsxs)(`nav`,{className:`bottom-navigation`,children:[(0,c.jsxs)(`button`,{className:e===`home`?`active`:``,onClick:()=>{t(`home`),window.scrollTo({top:0,behavior:`smooth`})},children:[(0,c.jsx)(`span`,{children:`⌂`}),(0,c.jsx)(`small`,{children:`Home`})]}),(0,c.jsxs)(`button`,{className:e===`matches`?`active`:``,onClick:()=>t(`matches`),children:[(0,c.jsx)(`span`,{children:`🏏`}),(0,c.jsx)(`small`,{children:`Matches`})]}),(0,c.jsxs)(`button`,{className:e===`contests`?`active`:``,onClick:()=>t(`contests`),children:[(0,c.jsx)(`span`,{children:`🏆`}),(0,c.jsx)(`small`,{children:`Contests`})]}),(0,c.jsxs)(`button`,{className:e===`teams`?`active`:``,onClick:()=>t(`teams`),children:[(0,c.jsx)(`span`,{children:`👥`}),(0,c.jsx)(`small`,{children:`My Teams`})]}),(0,c.jsxs)(`button`,{className:e===`profile`?`active`:``,onClick:()=>t(`profile`),children:[(0,c.jsx)(`span`,{children:`◉`}),(0,c.jsx)(`small`,{children:`Profile`})]})]})]})}(function(){if(typeof window>`u`)return;function e(e){let t=document.getElementById(`root`);if(!t)return;t.innerHTML=`
      <div class="bz-flow-screen">
        <div class="bz-flow-head">
          <div>
            <div style="color:#24e778;font-size:12px;font-weight:900;letter-spacing:2px">BATZO CRICKET</div>
            <h1>Create Team</h1>
            <div style="color:#8f97a5;margin-top:4px">${e} • Select your XI</div>
          </div>
          <button class="bz-flow-back" id="bzBack">← Back</button>
        </div>

        <div id="bzPlayers"></div>

        <div class="bz-flow-bottom">
          <button class="bz-flow-primary" id="bzTeamContinue">CONTINUE • 0/11</button>
        </div>
      </div>
    `;let n=document.getElementById(`bzPlayers`),i=new Set;r.forEach((e,t)=>{let r=document.createElement(`div`);r.className=`bz-flow-card`,r.innerHTML=`
        <div class="bz-flow-player">
          <div class="bz-flow-photo">
            <img src="${e.photo}" alt="${e.name}">
          </div>
          <div class="bz-flow-player-info">
            <div class="bz-flow-player-name">${e.name}</div>
            <div class="bz-flow-player-meta">${e.team} • ${e.role}</div>
            <div class="bz-flow-credit">${e.credit} Credits</div>
          </div>
          <button class="bz-flow-select">ADD</button>
        </div>
      `;let a=r.querySelector(`button`);a.onclick=()=>{i.has(t)?(i.delete(t),a.textContent=`ADD`,a.classList.remove(`active`)):i.size<11&&(i.add(t),a.textContent=`✓`,a.classList.add(`active`)),document.getElementById(`bzTeamContinue`).textContent=`CONTINUE • `+i.size+`/11`},n.appendChild(r)}),document.getElementById(`bzBack`).onclick=()=>location.reload(),document.getElementById(`bzTeamContinue`).onclick=()=>{if(i.size<11){alert(`Please select 11 players.`);return}alert(`Team selected successfully. Captain & Vice-Captain selection is next.`)}}function t(t){let n=document.getElementById(`root`);n&&(n.innerHTML=`
      <div class="bz-flow-screen">
        <div class="bz-flow-head">
          <div>
            <div style="color:#24e778;font-size:12px;font-weight:900;letter-spacing:2px">CONTEST</div>
            <h1>${t.name}</h1>
          </div>
          <button class="bz-flow-back" id="bzContestBack">← Back</button>
        </div>

        <div class="bz-flow-card">
          <div style="color:#858d9a;font-size:11px;text-transform:uppercase;letter-spacing:1.5px">
            Winning Prize
          </div>

          <div class="bz-flow-prize">${t.prize}</div>

          <div style="margin-top:12px;color:#858d9a">Entry Fee</div>
          <div class="bz-flow-entry">${t.entry}</div>

          <div class="bz-flow-stats">
            <div class="bz-flow-stat">
              <strong>${t.spots}</strong>
              <span>SPOTS</span>
            </div>
            <div class="bz-flow-stat">
              <strong>${t.joined}</strong>
              <span>JOINED</span>
            </div>
            <div class="bz-flow-stat">
              <strong>11</strong>
              <span>PLAYERS</span>
            </div>
          </div>
        </div>

        <div class="bz-flow-card">
          <h3 style="color:#fff">Winning Breakdown</h3>
          <p style="color:#a1a8b4">Rank 1 — 40% Prize Pool</p>
          <p style="color:#a1a8b4">Rank 2 — 20% Prize Pool</p>
          <p style="color:#a1a8b4">Rank 3 — 10% Prize Pool</p>
          <p style="color:#a1a8b4">Other Winners — 30% Prize Pool</p>
        </div>

        <div class="bz-flow-bottom">
          <button class="bz-flow-primary" id="bzJoin">
            JOIN CONTEST • ${t.entry}
          </button>
        </div>
      </div>
    `,document.getElementById(`bzContestBack`).onclick=()=>location.reload(),document.getElementById(`bzJoin`).onclick=()=>{e(`IND vs AUS`)})}window.addEventListener(`batzo:team`,t=>{e(t.detail&&t.detail.match||`IND vs AUS`)}),window.addEventListener(`batzo:contest`,e=>{t(e.detail&&e.detail.contest||i[0])}),document.addEventListener(`click`,e=>{let t=e.target.closest(`button,a`);if(!t)return;let n=(t.innerText||``).trim().toUpperCase();if(n.includes(`VIEW CONTEST`)||n.includes(`JOIN CONTEST`)||n===`CONTESTS`){e.preventDefault(),e.stopPropagation(),o(i[0]);return}if(n.includes(`CREATE TEAM`)||n.includes(`BUILD YOUR XI`)||n===`MY TEAMS`){e.preventDefault(),e.stopPropagation(),a(`IND vs AUS`);return}},!0)})(),(function(){function e(e){let t=(i!==void 0&&Array.isArray(i)?i:[{id:`contest-001`,name:`Mega Contest`,prize:`₹1,00,000`,entry:`₹49`,spots:1e4,joined:3210}])[0];window.dispatchEvent(new CustomEvent(`batzo:contest`,{detail:{contest:t,match:e||`IND vs AUS`}}))}function t(t){let n=document.createElement(`button`);return n.type=`button`,n.className=`batzo-final-view-contests`,n.textContent=`VIEW CONTESTS`,n.style.cssText=[`display:block`,`width:100%`,`margin-top:12px`,`padding:12px 14px`,`border:0`,`border-radius:12px`,`background:linear-gradient(135deg,#24ef7b,#0fc966)`,`color:#031009`,`font-size:13px`,`font-weight:900`,`cursor:pointer`,`box-sizing:border-box`].join(`;`),n.addEventListener(`click`,function(n){n.preventDefault(),n.stopPropagation(),e(t||`IND vs AUS`)},!0),n}function n(e){return(e.innerText||e.textContent||``).replace(/\s+/g,` `).trim()}function r(){let e=[...document.querySelectorAll(`div,section,article,main`)],r=!1;if(e.forEach(e=>{if(!e||e.id===`root`)return;let i=n(e).toUpperCase();if(!i.includes(`UPCOMING`)||i.length>1800)return;r=!0;let a=e;for(let e=0;e<4&&a.parentElement;e++){let e=a.parentElement,t=n(e).toUpperCase();if(t.includes(`UPCOMING`)&&t.length<900)a=e;else break}if(a.querySelector(`.batzo-final-view-contests`))return;let o=n(a),s=`IND vs AUS`;o.includes(`IND`)&&o.includes(`AUS`)?s=`IND vs AUS`:o.includes(`IND`)&&o.includes(`ENG`)&&(s=`IND vs ENG`),a.appendChild(t(s))}),r&&!document.querySelector(`.batzo-final-view-contests`)){let e=[...document.querySelectorAll(`h1,h2,h3,h4,div,span`)].find(e=>n(e).toUpperCase()===`UPCOMING MATCHES`);if(e){let n=document.createElement(`div`);n.className=`batzo-final-generated-match`,n.style.cssText=[`margin:12px 0`,`padding:15px`,`border-radius:18px`,`background:linear-gradient(145deg,#121920,#090d11)`,`border:1px solid #29313a`,`color:#fff`].join(`;`),n.innerHTML=`
          <div style="
            color:#ffd43b;
            font-size:10px;
            font-weight:900;
            margin-bottom:10px;
          ">UPCOMING</div>

          <div style="
            display:flex;
            justify-content:space-between;
            align-items:center;
            font-weight:900;
            font-size:16px;
          ">
            <span>🇮🇳 INDIA</span>
            <span style="color:#24e778">VS</span>
            <span>🇦🇺 AUSTRALIA</span>
          </div>

          <div style="
            color:#818b97;
            font-size:10px;
            text-align:center;
            margin:9px 0;
          ">
            Upcoming Cricket Match
          </div>
        `,n.appendChild(t(`IND vs AUS`)),e.parentElement?.appendChild(n)}}}window.addEventListener(`batzo:open-upcoming-contest`,function(t){e(t.detail?.match||`IND vs AUS`)});function a(){try{r()}catch(e){console.warn(`BATZO upcoming repair:`,e)}}document.readyState===`complete`||document.readyState===`interactive`?(setTimeout(a,250),setTimeout(a,1e3),setTimeout(a,2500)):document.addEventListener(`DOMContentLoaded`,function(){setTimeout(a,250),setTimeout(a,1e3),setTimeout(a,2500)});let o=0;new MutationObserver(function(){clearTimeout(o),o=setTimeout(a,120)}).observe(document.documentElement,{childList:!0,subtree:!0})})();export{v as default};